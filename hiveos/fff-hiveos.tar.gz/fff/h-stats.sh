#!/usr/bin/env bash
# Parses fff's own text log (no JSON API) into the stats blob HiveOS expects.
# NOTE: not validated against a real HiveOS agent -- schema follows the
# documented custom-miner stats.json convention; verify the dashboard
# actually renders it and adjust field names if not.

cd "$(dirname "$0")" || exit 1
. ./h-manifest.conf

LOG="$CUSTOM_LOG_BASENAME.log"
LAST_STATS=$(grep '\[stats\]' "$LOG" 2>/dev/null | tail -1)

if [ -z "$LAST_STATS" ]; then
  echo '{"hs":[0],"hs_units":"ghs","ar":[0,0],"uptime":0,"algo":"pearl","ver":"1.0.0"}'
  exit 0
fi

# "... end-to-end 218.35 TH/s | shares=1/0 expected=0.61 P(0)=54.2%"
TH=$(echo "$LAST_STATS" | grep -oE 'end-to-end [0-9.]+ TH/s' | grep -oE '[0-9.]+')
ACCEPTED=$(echo "$LAST_STATS" | grep -oE 'shares=[0-9]+/[0-9]+' | cut -d= -f2 | cut -d/ -f1)
REJECTED=$(echo "$LAST_STATS" | grep -oE 'shares=[0-9]+/[0-9]+' | cut -d= -f2 | cut -d/ -f2)
TH=${TH:-0}
ACCEPTED=${ACCEPTED:-0}
REJECTED=${REJECTED:-0}

# TH/s -> GH/s (hs_units=ghs) so the reported number stays a manageable size.
GHS=$(awk -v th="$TH" 'BEGIN{printf "%.0f", th*1000}')

UPTIME=$(ps -C fff -o etimes= 2>/dev/null | head -1 | tr -d ' ')
UPTIME=${UPTIME:-0}

echo "{\"hs\":[$GHS],\"hs_units\":\"ghs\",\"ar\":[$ACCEPTED,$REJECTED],\"uptime\":$UPTIME,\"algo\":\"pearl\",\"ver\":\"1.0.0\"}"
