#!/usr/bin/env bash
# Builds the fff command-line arguments as $FFF_ARGS, from the HiveOS
# "Custom конфигурация" flight-sheet fields:
#   Имя майнера            -> CUSTOM_NAME (h-manifest.conf, not here)
#   Установочный URL       -> CUSTOM_URL  (h-manifest.conf, the PACKAGE
#                              download link -- NOT reused here for pool
#                              address, that would collide)
#   Кошелек и воркер шаблона -> wallet.worker template, e.g.
#                              "prl1p...yourwallet.%WORKER_NAME%"
#   Адрес пула             -> pool host:port
#   Пароль                 -> pool password
#   Доп. параметры конфигурации -> put "array" or "object" here (auth
#                              style; see README-hiveos.txt / main README's
#                              pool table). Defaults to "array" if empty.
#
# Exact HiveOS env var names for these fields are NOT verified against a
# real rig (no access to one) -- this tries several plausible names per
# field. The [h-run] log line always shows the final resolved `fff` command
# line, so check fff.log after first start to confirm what actually got
# picked up. fff.conf (edited directly over SSH) is the reliable fallback
# if none of them match.

cd "$(dirname "$0")" || exit 1

first_nonempty() {
  for v in "$@"; do
    [ -n "$v" ] && { echo "$v"; return; }
  done
}

TEMPLATE_VAL=$(first_nonempty "${CUSTOM_TEMPLATE:-}" "${TEMPLATE:-}" "${CUSTOM_USER_TEMPLATE:-}" "${WAL:-}")
WALLET_VAL="${TEMPLATE_VAL%%.*}"
WORKER_VAL="${TEMPLATE_VAL#*.}"
[ "$WORKER_VAL" = "$TEMPLATE_VAL" ] && WORKER_VAL=""

POOL_RAW=$(first_nonempty "${URL:-}" "${STRATUM_URL:-}" "${POOL:-}")
POOL_VAL="${POOL_RAW#stratum+tcp://}"
POOL_VAL="${POOL_VAL#stratum+ssl://}"

PASS_VAL=$(first_nonempty "${PASS:-}" "${EMAIL:-}")
PASS_VAL="${PASS_VAL:-x}"

AUTH_STYLE_VAL=$(echo "${CUSTOM_USER_CONFIG:-}" | tr -d ' \t\r\n')

if [ -z "$WALLET_VAL" ] && [ -f ./fff.conf ]; then
  # shellcheck disable=SC1091
  . ./fff.conf
  WALLET_VAL="$WALLET"
  WORKER_VAL="$WORKER_NAME"
  POOL_VAL="$POOL_HOST:$POOL_PORT"
  AUTH_STYLE_VAL="$AUTH_STYLE"
fi

if [ -z "$WALLET_VAL" ] || [ "$WALLET_VAL" = "prl1pYOUR_PRL_ADDRESS_HERE" ]; then
  echo "*** fff: no wallet configured. Fill in 'Кошелек и воркер шаблона' in the flight sheet (e.g. prl1p...yourwallet.%WORKER_NAME%), or edit fff.conf directly over SSH. ***"
  exit 1
fi

WORKER_VAL="${WORKER_VAL:-$(hostname)}"
POOL_HOST_VAL="${POOL_VAL%%:*}"
POOL_PORT_VAL="${POOL_VAL##*:}"
POOL_HOST_VAL="${POOL_HOST_VAL:-prl.kryptex.network}"
POOL_PORT_VAL="${POOL_PORT_VAL:-7048}"
case "$AUTH_STYLE_VAL" in
  array|object) ;;
  *) AUTH_STYLE_VAL="array" ;;
esac

FFF_ARGS="--wallet $WALLET_VAL --worker $WORKER_VAL --host $POOL_HOST_VAL --port $POOL_PORT_VAL --auth-style $AUTH_STYLE_VAL --password $PASS_VAL"
