#!/usr/bin/env bash
# Launches fff -- one process per detected GPU, each pinned via
# CUDA_VISIBLE_DEVICES, since fff itself has no multi-GPU support.
# Called by HiveOS's miner supervisor (source()'d by miner-run -- $0 refers
# to the CALLER's path when sourced, so cd via $MINER_DIR, which miner-run
# already sets, not dirname "$0". Falls back to dirname "$0" so this script
# also still works when executed directly, e.g. ./h-run.sh for testing).
#
# All GPUs share the SAME worker name (no per-GPU suffix) so the pool
# reports the rig as one worker with combined hashrate, not N separate
# workers. Per-GPU breakdown for the HiveOS dashboard (h-stats.sh) comes
# from separate per-GPU log files (fff-gpu0.log, fff-gpu1.log, ...) instead.
# Output is tee'd to both the per-GPU log and the shared fff.log (which also
# shows live in the `miner`/screen -r view, not just written to a file).

cd "${MINER_DIR:-$(dirname "$0")}" || exit 1
chmod +x ./fff 2>/dev/null

if ! ldconfig -p | grep -q libcublasLt.so.13; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] installing CUDA 13.3 runtime libs (cudart/cublas/cublasLt, one-time)..." | tee -a fff.log
  wget -qO /tmp/cuda-keyring.deb https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb \
    && sudo dpkg -i /tmp/cuda-keyring.deb \
    && sudo apt-get update -qq \
    && sudo apt-get install -y -qq cuda-cudart-13-3 libcublas-13-3
  if [ $? -ne 0 ]; then
    echo "*** fff: failed to install CUDA runtime libs. This rig may not be Ubuntu 22.04-based -- adjust the repo URL (ubuntu2204) in h-run.sh to match, or install libcudart/libcublas/libcublasLt 13.x manually. ***" | tee -a fff.log
    exit 1
  fi
fi

. ./h-manifest.conf
. ./h-config.sh
miner_config_gen || exit 1

GPU_COUNT=$(nvidia-smi -L 2>/dev/null | wc -l)
[ "$GPU_COUNT" -ge 1 ] 2>/dev/null || GPU_COUNT=1

rm -f fff-gpu*.log
echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] launching fff on $GPU_COUNT GPU(s), worker '$WORKER_VAL'" | tee -a fff.log

PIDS=()
cleanup() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] stopping all GPU workers" >> fff.log
  kill "${PIDS[@]}" 2>/dev/null
  wait
  exit 0
}
trap cleanup INT TERM

for ((i = 0; i < GPU_COUNT; i++)); do
  echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] starting GPU $i: ./fff --wallet $WALLET_VAL --worker $WORKER_VAL --host $POOL_HOST_VAL --port $POOL_PORT_VAL --auth-style $AUTH_STYLE_VAL" | tee -a fff.log
  # Process substitution (not a pipe) so $! below is fff's own PID, not
  # tee's -- needed so `kill "${PIDS[@]}"` in cleanup() actually signals
  # fff directly instead of relying on a broken-pipe/SIGPIPE side effect.
  CUDA_VISIBLE_DEVICES="$i" ./fff \
    --wallet "$WALLET_VAL" --worker "$WORKER_VAL" \
    --host "$POOL_HOST_VAL" --port "$POOL_PORT_VAL" \
    --auth-style "$AUTH_STYLE_VAL" --password "$PASS_VAL" \
    > >(tee -a "fff-gpu${i}.log" -a fff.log) 2>&1 &
  PIDS+=("$!")
done

wait
