#!/hive/sbin/bash-hive
# Launches fff. Called by HiveOS's miner supervisor.
#
# fff dynamically links libcudart.so.13/libcublas.so.13/libcublasLt.so.13
# (CUDA 13.3 runtime -- cublasLt alone is ~500MB, too big to bundle in the
# miner package itself), so the first run installs them from NVIDIA's apt
# repo if missing. Needs internet + apt on the rig; only runs once (checked
# via ldconfig each start, a no-op after the first successful install).

cd "$(dirname "$0")" || exit 1
chmod +x ./fff 2>/dev/null

if ! ldconfig -p | grep -q libcublasLt.so.13; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] installing CUDA 13.3 runtime libs (cudart/cublas/cublasLt, one-time)..." | tee -a fff.log
  wget -qO /tmp/cuda-keyring.deb https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.1-1_all.deb \
    && sudo dpkg -i /tmp/cuda-keyring.deb \
    && sudo apt-get update -qq \
    && sudo apt-get install -y -qq cuda-cudart-13-3 libcublas-13-3
  if [ $? -ne 0 ]; then
    echo "*** fff: failed to install CUDA runtime libs. This rig may not be Ubuntu 22.04-based -- adjust the repo URL (ubuntu2204) in h-run.sh to match, or install libcudart/libcublas/libcublasLt 13.x manually. ***" | tee -a fff.log
    exit 1
  fi
fi

. ./h-manifest.conf
. ./h-config.sh

echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] starting: ./fff $FFF_ARGS" >> "$CUSTOM_LOG_BASENAME.log"

# exec (not `&`) so HiveOS's screen session supervises fff directly instead
# of this wrapper shell.
# shellcheck disable=SC2086
exec ./fff $FFF_ARGS >> "$CUSTOM_LOG_BASENAME.log" 2>&1
