#!/usr/bin/env bash
# Parses fff's own text logs (no JSON API) into the stats blob HiveOS
# expects. One GPU per fff process (see h-run.sh), each with its own
# fff-gpuN.log -- builds one "hs" array entry per GPU, in GPU order, so the
# HiveOS dashboard's per-card table shows a real per-card breakdown instead
# of one aggregate number.

cd "${MINER_DIR:-$(dirname "$0")}" || exit 1
. ./h-manifest.conf

HS=()
TOTAL_ACCEPTED=0
TOTAL_REJECTED=0

shopt -s nullglob
GPU_LOGS=(fff-gpu*.log)
shopt -u nullglob

# Sort numerically by GPU index (fff-gpu0.log, fff-gpu1.log, ..., fff-gpu10.log)
IFS=$'\n' GPU_LOGS=($(printf '%s\n' "${GPU_LOGS[@]}" | sort -t u -k2 -n)); unset IFS

for log in "${GPU_LOGS[@]}"; do
  last_stats=$(grep '\[stats\]' "$log" 2>/dev/null | tail -1)
  th=0
  if [ -n "$last_stats" ]; then
    th=$(echo "$last_stats" | grep -oE 'end-to-end [0-9.]+ TH/s' | grep -oE '[0-9.]+')
    th=${th:-0}
    accepted=$(echo "$last_stats" | grep -oE 'shares=[0-9]+/[0-9]+' | cut -d= -f2 | cut -d/ -f1)
    rejected=$(echo "$last_stats" | grep -oE 'shares=[0-9]+/[0-9]+' | cut -d= -f2 | cut -d/ -f2)
    TOTAL_ACCEPTED=$((TOTAL_ACCEPTED + ${accepted:-0}))
    TOTAL_REJECTED=$((TOTAL_REJECTED + ${rejected:-0}))
  fi
  # TH/s -> GH/s (hs_units=ghs) so the reported number stays a manageable size.
  ghs=$(awk -v th="$th" 'BEGIN{printf "%.0f", th*1000}')
  HS+=("$ghs")
done

if [ ${#HS[@]} -eq 0 ]; then
  echo '{"hs":[0],"hs_units":"ghs","ar":[0,0],"uptime":0,"algo":"pearl","ver":""}'
  exit 0
fi

HS_JOINED=$(IFS=,; echo "${HS[*]}")
UPTIME=$(ps -C fff -o etimes= 2>/dev/null | sort -rn | head -1 | tr -d ' ')
UPTIME=${UPTIME:-0}

echo "{\"hs\":[$HS_JOINED],\"hs_units\":\"ghs\",\"ar\":[$TOTAL_ACCEPTED,$TOTAL_REJECTED],\"uptime\":$UPTIME,\"algo\":\"pearl\",\"ver\":\"\"}"
