#!/usr/bin/env bash
# Sourced by /hive/bin/agent's miner_stats() -- NOT executed as its own
# process. Confirmed from reading /hive/bin/agent directly (2026-07-17):
# it runs `{ source h-manifest.conf; source h-config.sh; source h-stats.sh;
# } 1>&2` -- our stdout is thrown away (redirected to stderr). What it
# actually reads afterward is the shell variables $khs (a single combined
# number) and $stats (a JSON string) that this file is expected to SET as a
# side effect of being sourced. This was the real reason nothing ever
# showed on the HiveOS dashboard, regardless of what this script printed.
# No `exit` here either -- this runs inside `source`, and while it's inside
# a process-substitution subshell (safe to exit), setting variables and
# falling through is simpler and avoids relying on that safety.

cd "${MINER_DIR:-$(dirname "$0")}" 2>/dev/null

HS=()
TOTAL_ACCEPTED=0
TOTAL_REJECTED=0

shopt -s nullglob
GPU_LOGS=(fff-gpu*.log)
shopt -u nullglob
if [ ${#GPU_LOGS[@]} -gt 0 ]; then
  IFS=$'\n' GPU_LOGS=($(printf '%s\n' "${GPU_LOGS[@]}" | sort -t u -k2 -n)); unset IFS
fi

for log in "${GPU_LOGS[@]}"; do
  last_stats=$(grep '\[stats\]' "$log" 2>/dev/null | tail -1)
  th=0
  accepted=0
  rejected=0
  if [ -n "$last_stats" ]; then
    th=$(echo "$last_stats" | grep -oE 'end-to-end [0-9.]+ TH/s' | grep -oE '[0-9.]+')
    th=${th:-0}
    accepted=$(echo "$last_stats" | grep -oE 'shares=[0-9]+/[0-9]+' | cut -d= -f2 | cut -d/ -f1)
    rejected=$(echo "$last_stats" | grep -oE 'shares=[0-9]+/[0-9]+' | cut -d= -f2 | cut -d/ -f2)
  fi
  TOTAL_ACCEPTED=$((TOTAL_ACCEPTED + ${accepted:-0}))
  TOTAL_REJECTED=$((TOTAL_REJECTED + ${rejected:-0}))
  # TH/s -> GH/s so the reported number stays a manageable size.
  ghs=$(awk -v th="$th" 'BEGIN{printf "%.0f", th*1000}')
  HS+=("$ghs")
done

khs=0
for v in "${HS[@]}"; do khs=$((khs + v)); done

if [ ${#HS[@]} -eq 0 ]; then
  HS_JOINED="0"
else
  HS_JOINED=$(IFS=,; echo "${HS[*]}")
fi

UPTIME=$(ps -C fff -o etimes= 2>/dev/null | sort -rn | head -1 | tr -d ' ')
UPTIME=${UPTIME:-0}

stats="{\"hs\":[$HS_JOINED],\"hs_units\":\"ghs\",\"ar\":[$TOTAL_ACCEPTED,$TOTAL_REJECTED],\"uptime\":$UPTIME,\"algo\":\"pearl\"}"
