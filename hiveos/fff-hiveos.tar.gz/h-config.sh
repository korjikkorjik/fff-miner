#!/usr/bin/env bash
# miner-run (source of ground truth: /hive/bin/miner-run on a real rig,
# 2026-07-17) calls miner_ver() and miner_config_gen() as FUNCTIONS -- an
# undefined function here kills miner-run's whole config_miner() subshell
# via `( config_miner ) || exit $?`, which is why nothing ever started
# before this fix, for fff or (if its h-config.sh had the same shape issue)
# any other custom miner. CUSTOM_TEMPLATE/CUSTOM_URL/CUSTOM_PASS/
# CUSTOM_USER_CONFIG are sourced by miner-run from /hive-config/wallet.conf
# before this file is sourced. CUSTOM_URL is the POOL address here (HiveOS
# reserves CUSTOM_INSTALL_URL for the package download link).

miner_ver() {
  echo ""
}

miner_config_gen() {
  MINER_LOG_BASENAME="$MINER_DIR/$CUSTOM_LOG_BASENAME"

  WALLET_VAL="${CUSTOM_TEMPLATE%%.*}"
  WORKER_VAL="${CUSTOM_TEMPLATE#*.}"
  [ "$WORKER_VAL" = "$CUSTOM_TEMPLATE" ] && WORKER_VAL=""
  POOL_VAL="${CUSTOM_URL#stratum+tcp://}"
  POOL_VAL="${POOL_VAL#stratum+ssl://}"
  PASS_VAL="${CUSTOM_PASS:-x}"
  AUTH_STYLE_VAL=$(echo "${CUSTOM_USER_CONFIG:-}" | tr -d ' \t\r\n')

  if [ -z "$WALLET_VAL" ] && [ -f "$MINER_DIR/fff.conf" ]; then
    . "$MINER_DIR/fff.conf"
    WALLET_VAL="$WALLET"
    WORKER_VAL="$WORKER_NAME"
    POOL_VAL="$POOL_HOST:$POOL_PORT"
    AUTH_STYLE_VAL="$AUTH_STYLE"
  fi

  if [ -z "$WALLET_VAL" ] || [ "$WALLET_VAL" = "prl1pYOUR_PRL_ADDRESS_HERE" ]; then
    echo "*** fff: no wallet configured (checked flight sheet + fff.conf) ***"
    return 1
  fi

  WORKER_VAL="${WORKER_VAL:-$(hostname)}"
  POOL_HOST_VAL="${POOL_VAL%%:*}"
  POOL_PORT_VAL="${POOL_VAL##*:}"
  POOL_HOST_VAL="${POOL_HOST_VAL:-prl.kryptex.network}"
  POOL_PORT_VAL="${POOL_PORT_VAL:-7048}"
  case "$AUTH_STYLE_VAL" in
    array|object) ;;
    *) AUTH_STYLE_VAL="array" ;;
  esac
  return 0
}

miner_config_echo() {
  miner_config_gen
  echo "wallet: $WALLET_VAL"
  echo "worker: $WORKER_VAL"
  echo "pool:   $POOL_HOST_VAL:$POOL_PORT_VAL"
  echo "auth:   $AUTH_STYLE_VAL"
}
