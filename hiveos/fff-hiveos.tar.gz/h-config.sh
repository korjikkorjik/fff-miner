#!/hive/sbin/bash-hive
# Builds the fff command-line arguments as $FFF_ARGS.
#
# Tries HiveOS Flight Sheet variables first ($WALLET, $WORKER_NAME,
# $CUSTOM_TEMPLATE with %WAL%/%WORKER_NAME%/%URL% placeholders, $CUSTOM_URL
# for pool host:port). If those aren't populated (not verified against a
# real HiveOS rig -- flight-sheet variable names have changed between HiveOS
# versions before), falls back to a plain fff.conf file next to this script,
# which you can edit directly the same way as the Windows start.bat.

cd "$(dirname "$0")" || exit 1

WALLET_VAL="${WALLET:-}"
WORKER_VAL="${WORKER_NAME:-}"
POOL_VAL="${CUSTOM_URL:-}"
AUTH_STYLE_VAL="${CUSTOM_USER_CONFIG:-}"

if [ -z "$WALLET_VAL" ] && [ -f ./fff.conf ]; then
  # shellcheck disable=SC1091
  . ./fff.conf
  WALLET_VAL="$WALLET"
  WORKER_VAL="$WORKER_NAME"
  POOL_VAL="$POOL_HOST:$POOL_PORT"
  AUTH_STYLE_VAL="$AUTH_STYLE"
fi

if [ -z "$WALLET_VAL" ] || [ "$WALLET_VAL" = "prl1pYOUR_PRL_ADDRESS_HERE" ]; then
  echo "*** fff: no wallet configured. Edit fff.conf in this folder (WALLET=prl1p...) or set the flight sheet wallet field. ***"
  exit 1
fi

WORKER_VAL="${WORKER_VAL:-$(hostname)}"
POOL_HOST_VAL="${POOL_VAL%%:*}"
POOL_PORT_VAL="${POOL_VAL##*:}"
POOL_HOST_VAL="${POOL_HOST_VAL:-prl.kryptex.network}"
POOL_PORT_VAL="${POOL_PORT_VAL:-7048}"
AUTH_STYLE_VAL="${AUTH_STYLE_VAL:-array}"
case "$AUTH_STYLE_VAL" in
  array|object) ;;
  *) AUTH_STYLE_VAL="array" ;;
esac

FFF_ARGS="--wallet $WALLET_VAL --worker $WORKER_VAL --host $POOL_HOST_VAL --port $POOL_PORT_VAL --auth-style $AUTH_STYLE_VAL"
