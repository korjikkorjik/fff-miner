#!/usr/bin/env bash
# Sourced through HiveOS's shared custom-miner config wrapper.
# CUSTOM_TEMPLATE/CUSTOM_URL/CUSTOM_PASS/CUSTOM_USER_CONFIG come from the
# flight sheet. CUSTOM_URL is the pool address; CUSTOM_INSTALL_URL is the
# package download URL.

FFF_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)

miner_ver() {
  echo ""
}

miner_config_gen() {
  MINER_LOG_BASENAME="$FFF_DIR/$CUSTOM_LOG_BASENAME"

  WALLET_VAL="${CUSTOM_TEMPLATE%%.*}"
  WORKER_VAL="${CUSTOM_TEMPLATE#*.}"
  [ "$WORKER_VAL" = "$CUSTOM_TEMPLATE" ] && WORKER_VAL=""
  POOL_VAL="${CUSTOM_URL#stratum+tcp://}"
  POOL_VAL="${POOL_VAL#stratum+ssl://}"
  PASS_VAL="${CUSTOM_PASS:-x}"
  AUTH_STYLE_VAL=$(echo "${CUSTOM_USER_CONFIG:-}" | tr -d ' \t\r\n')

  if [ -z "$WALLET_VAL" ] && [ -f "$FFF_DIR/fff.conf" ]; then
    . "$FFF_DIR/fff.conf"
    WALLET_VAL="$WALLET"
    WORKER_VAL="$WORKER_NAME"
    POOL_VAL="$POOL_HOST:$POOL_PORT"
    AUTH_STYLE_VAL="$AUTH_STYLE"
  fi

  if [ -z "$WALLET_VAL" ] || [ "$WALLET_VAL" = "prl1pYOUR_PRL_ADDRESS_HERE" ]; then
    echo "*** fff: no wallet configured (checked flight sheet + fff.conf) ***"
    return 1
  fi

  WORKER_VAL="${WORKER_VAL:-$(hostname)}"
  POOL_HOST_VAL="${POOL_VAL%%:*}"
  POOL_PORT_VAL="${POOL_VAL##*:}"
  POOL_HOST_VAL="${POOL_HOST_VAL:-prl.kryptex.network}"
  POOL_PORT_VAL="${POOL_PORT_VAL:-7048}"
  case "$AUTH_STYLE_VAL" in
    array|object) ;;
    *) AUTH_STYLE_VAL="array" ;;
  esac
  return 0
}

miner_config_echo() {
  miner_config_gen
  echo "wallet: $WALLET_VAL"
  echo "worker: $WORKER_VAL"
  echo "pool:   $POOL_HOST_VAL:$POOL_PORT_VAL"
  echo "auth:   $AUTH_STYLE_VAL"
}
