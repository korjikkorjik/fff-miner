#!/usr/bin/env bash
# Launches fff -- one process per detected GPU, each pinned via
# CUDA_VISIBLE_DEVICES, since fff itself has no multi-GPU support.
# Called by HiveOS's miner supervisor (source()'d by miner-run -- $0 refers
# to the CALLER's path when sourced, so cd via $MINER_DIR, which miner-run
# already sets, not dirname "$0". Falls back to dirname "$0" so this script
# also still works when executed directly, e.g. ./h-run.sh for testing).
#
# All GPUs share the SAME worker name (no per-GPU suffix) so the pool
# reports the rig as one worker with combined hashrate, not N separate
# workers. Per-GPU breakdown for the HiveOS dashboard (h-stats.sh) comes
# from separate per-GPU log files (fff-gpu0.log, fff-gpu1.log, ...) instead.
# Output is tee'd to both the per-GPU log and the shared fff.log (which also
# shows live in the `miner`/screen -r view, not just written to a file).

cd "${MINER_DIR:-$(dirname "$0")}" || exit 1
FFF_BIN=./fff.bin
chmod +x "$FFF_BIN" 2>/dev/null
if [ ! -x "$FFF_BIN" ]; then
  echo "*** fff: $FFF_BIN is missing or not executable. ***" | tee -a fff.log
  exit 1
fi

# The HiveOS binary contains the CUDA runtime and uses FFF's fused kernels.
# It never installs packages or modifies the rig's system CUDA environment.

. ./h-manifest.conf
. ./h-config.sh
miner_config_gen || exit 1

GPU_COUNT=$(nvidia-smi -L 2>/dev/null | wc -l)
[ "$GPU_COUNT" -ge 1 ] 2>/dev/null || GPU_COUNT=1

rm -f fff-gpu*.log
echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] launching fff on $GPU_COUNT GPU(s), worker '$WORKER_VAL'" | tee -a fff.log

# Log size cap: fff runs for weeks at a time and prints a [stats] line every
# few seconds per GPU, so fff.log/fff-gpuN.log grow unbounded otherwise.
# Self-contained (no dependency on the rig's system logrotate/cron actually
# being configured) -- checks every 5 minutes, trims any log over 20MB back
# down to its last 5MB.
MAX_LOG_BYTES=$((20 * 1024 * 1024))
KEEP_LOG_BYTES=$((5 * 1024 * 1024))
log_trimmer() {
  while true; do
    sleep 300
    for f in fff.log fff-gpu*.log; do
      [ -f "$f" ] || continue
      size=$(stat -c%s "$f" 2>/dev/null || echo 0)
      if [ "$size" -gt "$MAX_LOG_BYTES" ]; then
        tail -c "$KEEP_LOG_BYTES" "$f" > "${f}.trim" 2>/dev/null && mv "${f}.trim" "$f"
      fi
    done
  done
}
log_trimmer &
TRIMMER_PID=$!

PIDS=()
cleanup() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] stopping all GPU workers" >> fff.log
  kill "$TRIMMER_PID" 2>/dev/null
  kill "${PIDS[@]}" 2>/dev/null
  wait
  exit 0
}
trap cleanup INT TERM

for ((i = 0; i < GPU_COUNT; i++)); do
  echo "$(date '+%Y-%m-%d %H:%M:%S') [h-run] starting GPU $i: $FFF_BIN --wallet $WALLET_VAL --worker $WORKER_VAL --host $POOL_HOST_VAL --port $POOL_PORT_VAL --auth-style $AUTH_STYLE_VAL" | tee -a fff.log
  # Process substitution (not a pipe) so $! below is fff's own PID, not
  # tee's -- needed so `kill "${PIDS[@]}"` in cleanup() actually signals
  # fff directly instead of relying on a broken-pipe/SIGPIPE side effect.
  CUDA_VISIBLE_DEVICES="$i" "$FFF_BIN" \
    --wallet "$WALLET_VAL" --worker "$WORKER_VAL" \
    --host "$POOL_HOST_VAL" --port "$POOL_PORT_VAL" \
    --auth-style "$AUTH_STYLE_VAL" --password "$PASS_VAL" \
    > >(tee -a "fff-gpu${i}.log" -a fff.log) 2>&1 &
  PIDS+=("$!")
done

wait
